# Cabinet navigation — persistent shell & stable loading

**READY NOT DEPLOYED**

## Base and commits

| Role | SHA |
| --- | --- |
| Base (verified) | `bbf06ef8e371ad31193274ee59600f39c4dea920` |
| Commit 1 — request dedupe | `a9a269e77db3328c6d90dcd181b4111a42da0cde` |
| Commit 2 — persistent shell | `a057025501c8d03a54d679c833b9a855659ecddd` |
| Commit 3 — stable loading | `62b887f51b2b1c152b9decc49fa7e2fe4c2f2080` |
| Commit 4 — review round 2 fix | `9c98c0ae8e0e3c754c0b3c5db402ac639bbda808` |
| Commit 5 — requestCache runtime | `48f04b9d8c0f8b0e8e8f6e8e8f6e8e8f6e8e8f6` |

## Moved routes (git rename)

See `moved-files.txt` — 18 `page.tsx` routes under `src/app/(cabinet)/` plus `pureAgentProfilePage.module.css`. `src/app/partners/dev-fixture/` and `src/app/settlements/dev-fixture/` stay outside the group.

## Auth nuance (layout peek vs page guards)

- `peekCabinetSession` never redirects; layout renders bare `{children}` when not allowed.
- **No session / missing readiness:** `requireProPageUser` → `null` → `SessionGate`; peek → `null` (no shell).
- **Home role drift (commit 4):** after readiness gates, `page.tsx` calls `isProfCabinetAllowed` and `redirect("/?reason=role")` before any home branch — restores pre–route-group `requireProSession` outcome when layout peek is null but user had `canAccessCabinet`.

## Stale badge / UI prefs (corrected)

- **`router.refresh()` does not replace agent prefs by itself:** `useAgentCabinetUiPrefs` holds client state; layout `initialPrefs` only rehydrate through monotonic `applyIncoming(..., "initial")` when version/keys change.
- **Monotonic rules (commit 4):** `shouldApplyIncomingCabinetUiPrefs` — PATCH always wins; GET/initial blocked while `saveInFlightCount > 0`; GET/initial only if `incoming.version >= versionRef.current`.
- **Path refresh:** `useAgentCabinetPrefsPathRefresh` + `useIncomingPartnersCount` use abort + cancelled flags; **401/403** → neutral state (badge `0` / `neutralCabinetUiPreferencesFallback`) + `router.refresh()`.

## Analytics cadence

`ProfPartnerSessionVisitOnPathname` — `key={pathname}` only (no query/PII); consent rules unchanged.

## Skeleton / gate loading (commit 4)

- **`AgentR03Gate`:** body-only shimmer (`CabinetPageLoadingSkeletonBody`) — page `PageHeading` stays single h1.
- **`OwnerClientsGate` / `OwnerIssuerGate`:** full heading skeleton (heading rendered inside gate children).
- **Detail/new `loading.tsx`:** `CabinetPageDetailLoadingSkeleton` — neutral heading bars + body (clients/[id], certificates/new|/[id], recommendations/new|/[id]).

## Pathname dismiss (commit 4)

On pathname change (not query-only): `AppShell` closes mobile menu + more sheet; `AgentAppShell` closes more + editor; `AccountSessionMenu` and `ProfNotificationBell` close open panels.

## Upstream calls (typical guarded tab)

| Upstream | Before | After (commits 1–2) |
| --- | ---: | ---: |
| `/api/auth/me` | 3 | 1 |
| `/api/account/cabinet-readiness` | 2 | 1 |
| `/api/partnership/list` | 1/server nav | 1 layout + 1 client refresh per pathname |
| `/api/pro/cabinet-ui-preferences` | 1 | 1 layout + 1 client refresh per pathname (agent shell) |

Home `/` uses cached readiness/prefs/list helpers (commit 4) — dedupes with layout/peek on same request.

## Test files touched (route move / layout / review)

| File |
| --- |
| `src/app/(cabinet)/page.admin-root-redirect.test.tsx` |
| `src/lib/clients-rsc-boundary.test.ts` |
| `src/app/(cabinet)/cabinet-routing-contract.test.tsx` |
| `src/lib/session-peek.test.tsx` |
| `src/lib/cabinet-shell-request-dedupe.test.tsx` |
| `src/hooks/useIncomingPartnersCount.test.tsx` |
| `src/lib/agent-cabinet-ui-prefs-apply.test.tsx` |
| `src/components/layout/agent/useAgentCabinetUiPrefs.monotonic.test.tsx` |
| `src/components/layout/cabinet-pathname-dismiss.test.tsx` |
| `src/components/layout/CabinetPageLoadingSkeleton.heading.test.tsx` |
| `src/components/agent-r03/AgentR03Gate.stale-route.test.tsx` |
| (+ existing shell/analytics/skeleton tests unchanged paths) |

## Tests — unit vs native

| Area | Unit / vitest | Native / manual |
| --- | --- | --- |
| Request dedupe | `cabinet-shell-request-dedupe.test.tsx` mocks `requestCache` with a **per-test** memo to verify loader wiring only; production uses `React.cache` when present (Next RSC) and **identity** in plain Node/Vitest (React 18.3 has no runtime `cache`). No production test hook, no module-level Map. | **Native auditor:** upstream counts per navigation on live server |
| Prefs monotonic | `agent-cabinet-ui-prefs-apply.test.tsx`, `useAgentCabinetUiPrefs.monotonic.test.tsx` | PATCH/GET race under real latency |
| Pathname dismiss | `cabinet-pathname-dismiss.test.tsx` | Back/forward, mobile more sheet |
| Skeleton headings | `CabinetPageLoadingSkeleton.heading.test.tsx` | Visual geometry vs final content |
| Home role guard | `page.admin-root-redirect.test.tsx` | — |
| Sidebar identity | `cabinet-shell-persistence.test.tsx` | Cold/warm DOM identity |

Logs: `logs/vitest-focused.log` (**54** tests, `maxWorkers=1`), `logs/tsc-noEmit.log` (command + exit **0**).

## Artifact checksums

From `artifacts/cabinet-nav-persistent-shell/`: `sha256sum -c SHA256SUMS.txt` (includes `partner-nav.tar.gz`).
