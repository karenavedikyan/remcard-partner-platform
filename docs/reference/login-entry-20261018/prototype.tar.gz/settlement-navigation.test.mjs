import assert from "node:assert/strict";
import { renderSettlementDemo, openSettlementPartner } from "./settlement-demo.js";
import { renderWallet } from "./cabinet-sections.js";

const config = (role) => ({ role, allowed: ["settlements", "requisites"], canCash: () => true, canTransfer: () => true });
for (const role of ["specialist", "store", "company", "agent"]) {
  const c = config(role), overview = renderWallet(c);
  assert.ok(overview.includes('data-testid="wallet-receivable"'));
  assert.equal(overview.includes('data-testid="wallet-payable"'), role !== "agent");
  assert.equal(overview.includes('data-testid="settlement-direction:out"'), role !== "agent");
  assert.ok(!overview.includes('data-testid="ledger-partners"'));
  assert.ok(!overview.includes('data-testid="ledger-stats"'));
  assert.ok(!overview.includes('data-testid="settlement-record-partial"'));
  openSettlementPartner(c, "materials");
  const detail = renderSettlementDemo(c);
  assert.ok(detail.includes('data-testid="settlement-record-partial"'));
  assert.ok(detail.includes('data-settlement-record="partial"'));
  assert.ok(!detail.includes('data-settlement-record="partial" data-testid="settlement-details-partial" open'));
  assert.ok(detail.includes('data-testid="settlement-filter:history"'));
  assert.ok(detail.includes('data-testid="settlement-filter:reconciliation"'));
}
console.log("Compact settlement navigation: all assertions passed.");
