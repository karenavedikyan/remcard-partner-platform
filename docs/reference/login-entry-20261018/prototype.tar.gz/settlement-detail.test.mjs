import assert from "node:assert/strict";
import { orderLines, orderTotals } from "./settlement-order-detail.js";
import { ledgerMetadata } from "./settlement-analysis.js";
import { journal, reconcile, renderReconciliation } from "./settlement-reconciliation.js";
const source = [
  ["partial", "in", "materials", 100000, 5, 5000, 2000, "partial"],
  ["outgoing", "out", "master", 60000, 5, 3000, 0, "due"],
  ["pending", "in", "light", 30000, 5, 1500, 0, "pending"],
  ["paid", "in", "tile", 80000, 5, 4000, 4000, "paid"],
  ["cancelled", "in", "materials", 20000, 5, 1000, 0, "cancelled"],
  ["materials-out", "out", "materials", 50000, 2, 1000, 0, "due"],
  ["materials-order2", "out", "materials", 50000, 5, 2500, 0, "due"],
  ["materials-order3", "out", "materials", 40000, 5, 2000, 500, "partial"],
];
const records = source.map(([id, direction, partnerId, purchase, rate, total, paid, status]) => {
  const r = { id, direction, partnerId, purchase, rate, total, paid, status, ...ledgerMetadata(id), orderId: `ORDER-${id}`, certificateId: `CERT-${id}` };
  r.history = [
    { type: status === "pending" ? "note" : "obligation", at: r.createdAt, amount: total },
    ...(paid ? [{ type: "payment", method: "transfer", at: new Date(Date.parse(r.createdAt) + (id === "materials-order3" ? 3600000 : 86400000)).toISOString(), amount: paid }] : []),
    ...(status === "cancelled" ? [{ type: "cancel", at: new Date(Date.parse(r.createdAt) + 86400000).toISOString(), amount: total }] : []),
  ];
  return r;
});
for (const r of records) {
  const totals = orderTotals(r);
  assert.equal(totals.net, r.purchase * 100);
  assert.equal(totals.fee, r.total * 100);
  assert.equal(totals.gross - totals.discount, totals.net);
  assert.equal(orderLines(r).length, 2);
}
assert.deepEqual(orderTotals(records[0]), { gross: 11666667, discount: 1666667, net: 10000000, fee: 500000 });
const partner = records.filter((r) => r.partnerId === "materials");
const full = { from: "2026-10-01", to: "2026-10-14" };
let result = reconcile(partner, full);
assert.deepEqual(result.in, { opening: 0, obligations: 600000, payments: 200000, cancellations: 100000, closing: 300000 });
assert.deepEqual(result.out, { opening: 0, obligations: 550000, payments: 50000, cancellations: 0, closing: 500000 });
result = reconcile(partner, { from: "2026-10-14", to: "2026-10-14" });
assert.deepEqual(result.out, { opening: 100000, obligations: 450000, payments: 50000, cancellations: 0, closing: 500000 });
assert.equal(result.in.opening, 300000);
result = reconcile(partner, { from: "2026-10-12", to: "2026-10-12" });
assert.equal(result.events.length, 0);
assert.equal(result.in.closing, 300000);
assert.equal(reconcile(partner, { from: "", to: full.to }).invalid, true);
assert.equal(reconcile(partner, { from: "2026-10-20", to: full.to }).invalid, true);
assert.equal(reconcile(partner, { from: "2026-02-31", to: full.to }).invalid, true);
assert.equal(journal(records.filter((r) => r.status === "pending")).length, 0);
partner[0].history.push({ type: "note", at: "2026-10-14T16:00:00+03:00", amount: 3000, title: "Запрос / отказ / отмена запроса" });
assert.equal(reconcile(partner, full).in.closing, 300000);
for (const id of ["materials-out", "materials-order2"]) {
  const r = partner.find((row) => row.id === id);
  r.history.push({ type: "payment", at: "2026-10-14T16:31:00+03:00", amount: r.total, paymentId: "GROUP-1", method: "cash" });
}
assert.equal(reconcile(partner, full).out.closing, 150000);
const html = renderReconciliation({ records: partner, partner: "materials", partnerName: "Demo", reconciliation: full }, {
  money: (v) => `${v} RUB`, esc: String, button: (label) => `<button>${label}</button>`, orderSummary: () => "",
});
assert.equal((html.match(/Подтверждена общая выплата/g) || []).length, 1);
assert.ok(html.includes("3500 RUB"));
assert.ok(html.includes("Доля общей выплаты"));
const agentHtml = renderReconciliation({ records: partner, partner: "materials", partnerName: "Demo", reconciliation: full, incomingOnly: true }, {
  money: (v) => `${v} RUB`, esc: String, button: (label) => `<button>${label}</button>`, orderSummary: () => "",
});
assert.ok(!agentHtml.includes("Я должен"));
assert.ok(!agentHtml.includes("reconciliation-out"));
assert.ok(!agentHtml.includes("ORDER-materials-out"));
assert.ok(agentHtml.includes("reconciliation-in"));
const boundary = { ...records[0], history: [{ type: "obligation", at: "2026-10-13T21:30:00Z", amount: 5000 }] };
assert.equal(reconcile([boundary], { from: "2026-10-14", to: "2026-10-14" }).in.obligations, 500000);
console.log("Order detail and reconciliation: all assertions passed.");
